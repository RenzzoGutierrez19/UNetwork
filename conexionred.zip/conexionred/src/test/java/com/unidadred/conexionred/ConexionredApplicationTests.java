package com.unidadred.conexionred;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConexionredApplicationTests {

	@Test
	void contextLoads() {
	}

}
